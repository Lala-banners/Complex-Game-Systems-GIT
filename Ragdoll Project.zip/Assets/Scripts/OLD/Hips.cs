using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hips : MonoBehaviour
{
    public Rigidbody hipsRB;

    // Start is called before the first frame update
    void Start()
    {
        hipsRB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
